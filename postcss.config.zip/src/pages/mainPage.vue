<script setup lang="ts">
  import DegradadoA from '@/assets/degradadoaA.vue';
</script>

<template>
  <nav>saporiia</nav>
  <div class="flex flex-col w-full h-full">
    <div class="w-full h-full flex justify-center">
      <degradadoA class="w-full h-full absolute -z-10" />
      <h1 class="text-[4rem] font-regular mt-96 text-center">
        ¡Deja que <span class="font-thin">Saporiia</span> <br />
        te inspire en la cocina!
      </h1>
    </div>
    <div>
      <div class="flex">
        <div>
          <p>
            "Saporiia nace de la idea de fusionar la inteligencia artificial con la pasión por la
            cocina. ¡Descubre un universo de sabores adaptados a tu estilo de vida con nuestras
            recomendaciones personalizadas de recetas!"
          </p>
        </div>
        <div></div>
      </div>
    </div>
  </div>
</template>

<style scoped></style>
