<script setup lang="ts"></script>

<template>
  <svg
    width="1512"
    height="1050"
    viewBox="0 0 1512 1050"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g filter="url(#filter0_f_8_71)">
      <ellipse cx="517" cy="506" rx="402" ry="313" fill="url(#paint0_linear_8_71)" />
    </g>
    <g filter="url(#filter1_f_8_71)">
      <ellipse cx="969" cy="517.5" rx="404" ry="353.5" fill="url(#paint1_linear_8_71)" />
    </g>
    <defs>
      <filter
        id="filter0_f_8_71"
        x="-63.1"
        y="14.9"
        width="1160.2"
        height="982.2"
        filterUnits="userSpaceOnUse"
        color-interpolation-filters="sRGB"
      >
        <feFlood flood-opacity="0" result="BackgroundImageFix" />
        <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
        <feGaussianBlur stdDeviation="89.05" result="effect1_foregroundBlur_8_71" />
      </filter>
      <filter
        id="filter1_f_8_71"
        x="386.9"
        y="-14.1"
        width="1164.2"
        height="1063.2"
        filterUnits="userSpaceOnUse"
        color-interpolation-filters="sRGB"
      >
        <feFlood flood-opacity="0" result="BackgroundImageFix" />
        <feBlend mode="normal" in="SourceGraphic" in2="BackgroundImageFix" result="shape" />
        <feGaussianBlur stdDeviation="89.05" result="effect1_foregroundBlur_8_71" />
      </filter>
      <linearGradient
        id="paint0_linear_8_71"
        x1="213.229"
        y1="327.845"
        x2="436.636"
        y2="621.792"
        gradientUnits="userSpaceOnUse"
      >
        <stop stop-color="#16A085" />
        <stop offset="1" stop-color="#F4D03F" />
      </linearGradient>
      <linearGradient
        id="paint1_linear_8_71"
        x1="663.718"
        y1="316.292"
        x2="922.368"
        y2="619.121"
        gradientUnits="userSpaceOnUse"
      >
        <stop stop-color="#B1F4CF" />
        <stop offset="1" stop-color="#9890E3" />
      </linearGradient>
    </defs>
  </svg>
</template>

<style scoped></style>
